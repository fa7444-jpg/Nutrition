
import os, sqlite3
import psycopg
from psycopg.rows import dict_row

SQLITE_PATH=os.getenv("SQLITE_PATH","equipment.db")
DATABASE_URL=os.environ["DATABASE_URL"]

schema=open("cloud_schema.sql",encoding="utf-8").read()
sq=sqlite3.connect(SQLITE_PATH)
sq.row_factory=sqlite3.Row

with psycopg.connect(DATABASE_URL) as pg:
    with pg.cursor() as cur:
        cur.execute(schema)
        tables=["devices","maintenance","faults","users","audit_log","documents"]
        for table in tables:
            rows=sq.execute(f"SELECT * FROM {table}").fetchall()
            if not rows: continue
            cols=rows[0].keys()
            # Clear target table so the script can be safely rerun for a fresh target DB.
            cur.execute(f"TRUNCATE TABLE {table} RESTART IDENTITY CASCADE")
            cols_sql=",".join(cols)
            placeholders=",".join(["%s"]*len(cols))
            for row in rows:
                cur.execute(f"INSERT INTO {table} ({cols_sql}) VALUES ({placeholders})",
                            tuple(row[c] for c in cols))
    pg.commit()

sq.close()
print("Migration completed.")
