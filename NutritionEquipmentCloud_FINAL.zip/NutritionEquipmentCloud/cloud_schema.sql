
CREATE TABLE IF NOT EXISTS devices (
    id BIGSERIAL PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT,
    image TEXT,
    manufacturer TEXT,
    model TEXT,
    serial_number TEXT,
    asset_number TEXT,
    purchase_date DATE,
    purchase_price NUMERIC(12,2),
    service_years INTEGER,
    warranty_start DATE,
    warranty_end DATE,
    location TEXT,
    status TEXT DEFAULT 'يعمل',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS maintenance (
    id BIGSERIAL PRIMARY KEY,
    device_id BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    maintenance_type TEXT,
    maintenance_date DATE,
    next_date DATE,
    technician TEXT,
    cost NUMERIC(12,2),
    notes TEXT
);

CREATE TABLE IF NOT EXISTS faults (
    id BIGSERIAL PRIMARY KEY,
    device_id BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    fault_type TEXT,
    description TEXT,
    report_date DATE,
    status TEXT DEFAULT 'مفتوح',
    technician TEXT,
    repair_date DATE,
    repair_cost NUMERIC(12,2),
    notes TEXT
);

CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'موظف'
);

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    username TEXT,
    action TEXT,
    device_code TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS documents (
    id BIGSERIAL PRIMARY KEY,
    device_id BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    filename TEXT,
    original_name TEXT,
    uploaded_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_devices_status ON devices(status);
CREATE INDEX IF NOT EXISTS idx_devices_category ON devices(category);
CREATE INDEX IF NOT EXISTS idx_devices_location ON devices(location);
CREATE INDEX IF NOT EXISTS idx_maintenance_next_date ON maintenance(next_date);
CREATE INDEX IF NOT EXISTS idx_faults_status ON faults(status);


CREATE TABLE IF NOT EXISTS handover_reports (
    id BIGSERIAL PRIMARY KEY,
    report_no TEXT UNIQUE NOT NULL,
    device_id BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    report_type TEXT NOT NULL,
    from_location TEXT,
    to_location TEXT,
    handover_by TEXT,
    received_by TEXT,
    report_date DATE,
    device_condition TEXT,
    notes TEXT,
    handover_signature TEXT,
    received_signature TEXT
);


CREATE TABLE IF NOT EXISTS suppliers (
    id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, contact TEXT, phone TEXT, email TEXT,
    contract_no TEXT, contract_start DATE, contract_end DATE, contract_cost NUMERIC(12,2), notes TEXT
);
CREATE TABLE IF NOT EXISTS spare_parts (
    id BIGSERIAL PRIMARY KEY, device_id BIGINT REFERENCES devices(id) ON DELETE CASCADE,
    name TEXT NOT NULL, quantity INTEGER DEFAULT 1, unit_cost NUMERIC(12,2) DEFAULT 0,
    used_date DATE, technician TEXT, notes TEXT
);
CREATE TABLE IF NOT EXISTS service_requests (
    id BIGSERIAL PRIMARY KEY, request_no TEXT UNIQUE NOT NULL, device_id BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    requester TEXT, issue_type TEXT, description TEXT, priority TEXT DEFAULT 'متوسط', status TEXT DEFAULT 'جديد',
    photo TEXT, created_at TIMESTAMPTZ DEFAULT NOW(), assigned_to TEXT, started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ, resolution TEXT, repair_cost NUMERIC(12,2) DEFAULT 0
);
