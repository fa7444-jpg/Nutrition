import secrets
import os
from flask import Flask, render_template, request, redirect, url_for, jsonify, abort, session, flash
import sqlite3, os, uuid
from datetime import datetime, date
import qrcode

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "equipment.db")
QR_DIR = os.path.join(BASE, "static", "qr")
os.makedirs(QR_DIR, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret")
app.config["UPLOAD_FOLDER"] = os.path.join(BASE, "static", "uploads")
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
ALLOWED_EXT = {"png","jpg","jpeg","webp","pdf","doc","docx"}

def allowed_file(name):
    return "." in name and name.rsplit(".",1)[1].lower() in ALLOWED_EXT

def login_required():
    return session.get("user") is not None



@app.context_processor
def alert_count():
    try:
        con=db()
        n=con.execute("""SELECT COUNT(*) FROM faults WHERE status!='مغلق'""").fetchone()[0]
        m=con.execute("""SELECT COUNT(*) FROM maintenance WHERE next_date IS NOT NULL AND date(next_date)<=date('now','+30 day')""").fetchone()[0]
        w=con.execute("""SELECT COUNT(*) FROM devices WHERE warranty_end IS NOT NULL AND date(warranty_end)<=date('now','+30 day')""").fetchone()[0]
        con.close()
        return {"alert_count":n+m+w}
    except Exception:
        return {"alert_count":0}

@app.context_processor
def inject_security():
    return {"csrf_token": csrf_token}

def csrf_token():
    token=session.get("_csrf")
    if not token:
        token=secrets.token_urlsafe(32)
        session["_csrf"]=token
    return token

def csrf_protect():
    if request.method in ("POST","PUT","PATCH","DELETE"):
        sent=request.form.get("_csrf") or request.headers.get("X-CSRF-Token")
        if not sent or sent != session.get("_csrf"):
            return "طلب غير صالح (CSRF)", 400

def role_required(*roles):
    def decorator(view):
        from functools import wraps
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("user"):
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                return "ليس لديك صلاحية لتنفيذ هذا الإجراء", 403
            return view(*args, **kwargs)
        return wrapped
    return decorator

def audit(con, action, device_id=None):
    con.execute("INSERT INTO audit_log(user_name, action, device_id, created_at) VALUES (?,?,?,CURRENT_TIMESTAMP)", (session.get("user","نظام"), action, device_id))

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        category TEXT,
        manufacturer TEXT,
        model TEXT,
        serial_number TEXT,
        asset_number TEXT,
        purchase_date TEXT,
        purchase_price REAL DEFAULT 0,
        service_years INTEGER DEFAULT 0,
        warranty_start TEXT,
        warranty_end TEXT,
        location TEXT,
        status TEXT DEFAULT 'يعمل',
        image TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS maintenance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id INTEGER NOT NULL,
        maintenance_date TEXT,
        next_date TEXT,
        maintenance_type TEXT,
        technician TEXT,
        company TEXT,
        cost REAL DEFAULT 0,
        notes TEXT,
        FOREIGN KEY(device_id) REFERENCES devices(id)
    );
    CREATE TABLE IF NOT EXISTS faults (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id INTEGER NOT NULL,
        report_date TEXT,
        fault_type TEXT,
        description TEXT,
        reporter TEXT,
        status TEXT DEFAULT 'مفتوح',
        technician TEXT,
        repair_date TEXT,
        repair_cost REAL DEFAULT 0,
        notes TEXT,
        FOREIGN KEY(device_id) REFERENCES devices(id)
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'موظف'
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_name TEXT,
        action TEXT,
        device_id INTEGER,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id INTEGER NOT NULL,
        title TEXT,
        file_name TEXT,
        FOREIGN KEY(device_id) REFERENCES devices(id)
    );
    """)
    count = con.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
    if count == 0:
        code = "NUT-OVN-001"
        con.execute("""INSERT INTO devices
        (code,name,category,manufacturer,model,serial_number,asset_number,
         purchase_date,purchase_price,service_years,warranty_start,warranty_end,
         location,status)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (code,"فرن حراري","أجهزة الطبخ","RATIONAL","iCombi Pro",
         "E61SJ220334567","NUT-OVN-001","2023-05-14",58000,3,
         "2023-05-14","2026-05-14","المطبخ الرئيسي","يعمل"))
    if con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        con.execute("INSERT INTO users(username,password,role) VALUES (?,?,?)",
                    ("admin","admin123","مديرة النظام"))
    con.commit(); con.close()

def make_qr(code):
    img = qrcode.make((public_base_url() + url_for("device", code=code)) if public_base_url() else url_for("device", code=code, _external=True))
    img.save(os.path.join(QR_DIR, f"{code}.png"))

def stats():
    con=db()
    total=con.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
    maintenance=con.execute("""SELECT COUNT(*) FROM devices
        WHERE status IN ('يحتاج صيانة','خارج الخدمة')""").fetchone()[0]
    faults=con.execute("SELECT COUNT(*) FROM faults WHERE status!='مغلق'").fetchone()[0]
    warranty=con.execute("""SELECT COUNT(*) FROM devices
        WHERE warranty_end IS NOT NULL AND warranty_end != ''
        AND date(warranty_end) BETWEEN date('now') AND date('now','+30 day')""").fetchone()[0]
    con.close()
    return total, maintenance, faults, warranty



@app.route("/scan")
def scan():
    if not login_required(): return redirect(url_for("login"))
    return render_template("scan.html")

@app.route("/device/<code>/qr")
def device_qr(code):
    if not login_required(): return redirect(url_for("login"))
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    con.close()
    if not d: return "الجهاز غير موجود",404
    return send_from_directory(app.config["QR_FOLDER"], f"{code}.png", as_attachment=True, download_name=f"QR-{code}.png")

@app.route("/device/<code>/label")
def device_label(code):
    if not login_required(): return redirect(url_for("login"))
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    con.close()
    if not d: return "الجهاز غير موجود",404
    return render_template("label.html", d=d)


@app.route("/device/<code>/edit", methods=["GET","POST"])
@role_required("مديرة النظام","مشرفة")
def edit_device(code):
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    if not d:
        con.close(); return "الجهاز غير موجود",404
    if request.method=="POST":
        fields=("name","category","manufacturer","model","serial_number","asset_number","purchase_date",
                "purchase_price","service_years","warranty_start","warranty_end","location","status")
        vals=[request.form.get(f,"").strip() for f in fields]
        image=d["image"]
        file=request.files.get("image")
        if file and file.filename and allowed_file(file.filename):
            import uuid, os
            ext=file.filename.rsplit(".",1)[1].lower()
            filename=f"{uuid.uuid4().hex}.{ext}"
            file.save(os.path.join(app.config["UPLOAD_FOLDER"],filename))
            image=filename
        vals.append(image)
        vals.append(code)
        con.execute("""UPDATE devices SET name=?,category=?,manufacturer=?,model=?,serial_number=?,
            asset_number=?,purchase_date=?,purchase_price=?,service_years=?,warranty_start=?,
            warranty_end=?,location=?,status=?,image=? WHERE code=?""", vals)
        con.commit(); con.close()
        audit("تعديل جهاز", code)
        flash("تم تحديث بيانات الجهاز بنجاح")
        return redirect(url_for("device",code=code))
    con.close()
    return render_template("edit.html", d=d)


@app.route("/change-password", methods=["GET","POST"])
@role_required("مديرة النظام","مشرفة","فني صيانة","موظف")
def change_password():
    con=db()
    user=con.execute("SELECT * FROM users WHERE username=?", (session.get("user"),)).fetchone()
    if request.method=="POST":
        current=request.form.get("current","")
        new=request.form.get("new","")
        confirm=request.form.get("confirm","")
        valid=(check_password_hash(user["password"],current) if user["password"].startswith(("scrypt:","pbkdf2:")) else user["password"]==current)
        if not valid: return "كلمة المرور الحالية غير صحيحة",400
        if len(new)<10: return "كلمة المرور الجديدة يجب ألا تقل عن 10 أحرف",400
        if new!=confirm: return "تأكيد كلمة المرور غير مطابق",400
        con.execute("UPDATE users SET password=? WHERE id=?", (generate_password_hash(new),user["id"]))
        con.commit(); con.close()
        audit("تغيير كلمة المرور", session.get("user"))
        return redirect(url_for("index"))
    con.close()
    return render_template("change_password.html")

@app.route("/users")
@role_required("مديرة النظام")
def users():
    con=db()
    rows=con.execute("SELECT id,username,role FROM users ORDER BY id").fetchall()
    con.close()
    return render_template("users.html", users=rows)

@app.route("/users/add", methods=["POST"])
@role_required("مديرة النظام")
def add_user():
    username=request.form.get("username","").strip()
    password=request.form.get("password","")
    role=request.form.get("role","موظف")
    if not username or not password: return "البيانات غير مكتملة",400
    con=db()
    try:
        con.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                    (username,generate_password_hash(password),role))
        con.commit()
    except Exception:
        con.close(); return "اسم المستخدم موجود مسبقًا",400
    con.close()
    audit("إضافة مستخدم", username)
    return redirect(url_for("users"))






@app.route("/device/<code>/handover", methods=["GET","POST"])
@role_required("مديرة النظام","مشرفة")
def handover_report(code):
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    if not d:
        con.close(); return "الجهاز غير موجود",404
    if request.method=="POST":
        import uuid
        report_no="NUT-HO-"+__import__("datetime").datetime.now().strftime("%Y%m%d%H%M%S")+"-"+uuid.uuid4().hex[:4].upper()
        vals=[request.form.get(k,"").strip() for k in ["report_type","to_location","handover_by","received_by","report_date","device_condition","notes","handover_signature","received_signature"]]
        con.execute("""INSERT INTO handover_reports(report_no,device_id,report_type,from_location,to_location,
                       handover_by,received_by,report_date,device_condition,notes,handover_signature,received_signature)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (report_no,d["id"],vals[0],d["location"] or "",vals[1],vals[2],vals[3],vals[4],vals[5],vals[6],vals[7],vals[8]))
        if vals[1]:
            con.execute("UPDATE devices SET location=? WHERE id=?",(vals[1],d["id"]))
        con.commit(); con.close()
        audit("إنشاء محضر استلام وتسليم", code)
        return redirect(url_for("handover_view",report_no=report_no))
    con.close()
    return render_template("handover.html",d=d)

@app.route("/handover/<report_no>")
@role_required("مديرة النظام","مشرفة","فني صيانة","موظف")
def handover_view(report_no):
    con=db()
    r=con.execute("""SELECT h.*,d.name,d.code,d.asset_number,d.serial_number,d.manufacturer,d.model
                     FROM handover_reports h JOIN devices d ON d.id=h.device_id WHERE h.report_no=?""",(report_no,)).fetchone()
    con.close()
    if not r: return "المحضر غير موجود",404
    return render_template("handover_view.html",r=r)

@app.route("/device/<code>/transfer", methods=["GET","POST"])
@role_required("مديرة النظام","مشرفة")
def transfer_device(code):
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    if not d:
        con.close(); return "الجهاز غير موجود",404
    if request.method=="POST":
        to_location=request.form.get("to_location","").strip()
        handover=request.form.get("handover_by","").strip()
        received=request.form.get("received_by","").strip()
        transfer_date=request.form.get("transfer_date","").strip()
        notes=request.form.get("notes","").strip()
        if not to_location or not received:
            con.close(); return "الموقع الجديد واسم المستلم مطلوبان",400
        con.execute("""INSERT INTO transfers(device_id,from_location,to_location,handover_by,received_by,transfer_date,notes)
                       VALUES(?,?,?,?,?,?,?)""",
                    (d["id"],d["location"] or "",to_location,handover,received,transfer_date,notes))
        con.execute("UPDATE devices SET location=? WHERE id=?",(to_location,d["id"]))
        con.commit(); con.close()
        audit("نقل جهاز", code)
        return redirect(url_for("timeline",code=code))
    con.close()
    return render_template("transfer.html",d=d)

@app.route("/device/<code>/timeline")
@role_required("مديرة النظام","مشرفة","فني صيانة","موظف")
def timeline(code):
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    if not d:
        con.close(); return "الجهاز غير موجود",404
    events=[]
    events.append({"date":d["purchase_date"] or d["created_at"] or "", "type":"شراء/إضافة",
                   "title":"إضافة الجهاز إلى النظام","text":f"تم تسجيل {d['name']} برقم الأصل {d['asset_number'] or '-'}","icon":"📦"})
    ms=con.execute("""SELECT * FROM maintenance WHERE device_id=? ORDER BY COALESCE(maintenance_date,next_date) DESC""",(d["id"],)).fetchall()
    for m in ms:
        events.append({"date":m["maintenance_date"] or m["next_date"] or "", "type":"صيانة",
                       "title":m["maintenance_type"] or "صيانة دورية",
                       "text":f"الفني: {m['technician'] or '-'} · التكلفة: {m['cost'] or 0} ر.س","icon":"🔧"})
    fs=con.execute("""SELECT * FROM faults WHERE device_id=? ORDER BY id DESC""",(d["id"],)).fetchall()
    for f in fs:
        events.append({"date":f["report_date"] or "", "type":"عطل",
                       "title":f["fault_type"] or "بلاغ عطل",
                       "text":f"{f['description'] or ''} · الحالة: {f['status']}","icon":"🚨"})
        if f["repair_date"]:
            events.append({"date":f["repair_date"],"type":"إصلاح",
                           "title":"إغلاق/إصلاح العطل",
                           "text":f"الفني: {f['technician'] or '-'} · تكلفة الإصلاح: {f['repair_cost'] or 0} ر.س","icon":"✅"})
    trs=con.execute("""SELECT * FROM transfers WHERE device_id=? ORDER BY id DESC""",(d["id"],)).fetchall()
    for tr in trs:
        events.append({"date":tr["transfer_date"] or "", "type":"نقل أصل",
                       "title":f"نقل الجهاز إلى {tr['to_location']}",
                       "text":f"من: {tr['from_location'] or '-'} · سلّمه: {tr['handover_by'] or '-'} · استلمه: {tr['received_by'] or '-'} · {tr['notes'] or ''}",
                       "icon":"🚚"})
    logs=con.execute("""SELECT * FROM audit_log WHERE device_code=? ORDER BY id DESC""",(code,)).fetchall()
    for l in logs:
        events.append({"date":l["created_at"] or "", "type":"سجل",
                       "title":l["action"],"text":f"بواسطة: {l['username'] or '-'}","icon":"📝"})
    con.close()
    events.sort(key=lambda x:str(x["date"] or ""), reverse=True)
    return render_template("timeline.html",d=d,events=events)


@app.route("/service-requests")
@role_required("مديرة النظام","مشرفة","فني صيانة","موظف")
def service_requests():
    con=db()
    rows=con.execute("""SELECT r.*,d.name device_name,d.code FROM service_requests r
                        JOIN devices d ON d.id=r.device_id ORDER BY r.id DESC""").fetchall()
    con.close()
    return render_template("service_requests.html",requests=rows)

@app.route("/device/<code>/service-request", methods=["GET","POST"])
@role_required("مديرة النظام","مشرفة","فني صيانة","موظف")
def create_service_request(code):
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?",(code,)).fetchone()
    if not d: con.close(); return "الجهاز غير موجود",404
    if request.method=="POST":
        import uuid, datetime, os
        no="SR-"+datetime.datetime.now().strftime("%Y%m%d%H%M%S")+"-"+uuid.uuid4().hex[:4].upper()
        photo=""
        f=request.files.get("photo")
        if f and f.filename and allowed_file(f.filename):
            ext=f.filename.rsplit(".",1)[1].lower()
            photo=f"{uuid.uuid4().hex}.{ext}"
            f.save(os.path.join(app.config["UPLOAD_FOLDER"],photo))
        con.execute("""INSERT INTO service_requests(request_no,device_id,requester,issue_type,description,priority,status,photo,created_at)
                       VALUES(?,?,?,?,?,?,?,?,datetime('now'))""",
                    (no,d["id"],session.get("user"),request.form.get("issue_type"),request.form.get("description"),
                     request.form.get("priority","متوسط"),"جديد",photo))
        con.execute("UPDATE devices SET status='يحتاج صيانة' WHERE id=?",(d["id"],))
        con.commit(); con.close()
        audit("إنشاء طلب صيانة",code)
        return redirect(url_for("service_request_view",request_no=no))
    con.close()
    return render_template("service_request_form.html",d=d)

@app.route("/service-request/<request_no>")
@role_required("مديرة النظام","مشرفة","فني صيانة","موظف")
def service_request_view(request_no):
    con=db()
    r=con.execute("""SELECT r.*,d.name device_name,d.code,d.asset_number FROM service_requests r
                     JOIN devices d ON d.id=r.device_id WHERE r.request_no=?""",(request_no,)).fetchone()
    con.close()
    if not r:return "الطلب غير موجود",404
    return render_template("service_request_view.html",r=r)

@app.route("/service-request/<request_no>/update", methods=["POST"])
@role_required("مديرة النظام","مشرفة","فني صيانة")
def update_service_request(request_no):
    con=db()
    r=con.execute("SELECT * FROM service_requests WHERE request_no=?",(request_no,)).fetchone()
    if not r: con.close(); return "الطلب غير موجود",404
    status=request.form.get("status",r["status"])
    assigned=request.form.get("assigned_to",r["assigned_to"] or "")
    resolution=request.form.get("resolution",r["resolution"] or "")
    cost=float(request.form.get("repair_cost") or 0)
    con.execute("""UPDATE service_requests SET status=?,assigned_to=?,resolution=?,repair_cost=?,
                   started_at=CASE WHEN ?='تحت المعالجة' AND started_at IS NULL THEN datetime('now') ELSE started_at END,
                   completed_at=CASE WHEN ?='مغلق' THEN datetime('now') ELSE completed_at END
                   WHERE request_no=?""",
                (status,assigned,resolution,cost,status,status,request_no))
    if status=="مغلق":
        con.execute("UPDATE devices SET status='يعمل' WHERE id=?",(r["device_id"],))
    else:
        con.execute("UPDATE devices SET status='يحتاج صيانة' WHERE id=?",(r["device_id"],))
    con.commit(); con.close()
    audit("تحديث طلب صيانة",request_no)
    return redirect(url_for("service_request_view",request_no=request_no))

@app.route("/suppliers")
@role_required("مديرة النظام","مشرفة")
def suppliers():
    con=db(); rows=con.execute("SELECT * FROM suppliers ORDER BY id DESC").fetchall(); con.close()
    return render_template("suppliers.html",suppliers=rows)

@app.route("/suppliers/add",methods=["POST"])
@role_required("مديرة النظام","مشرفة")
def add_supplier():
    con=db()
    con.execute("""INSERT INTO suppliers(name,contact,phone,email,contract_no,contract_start,contract_end,contract_cost,notes)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                tuple(request.form.get(k,"").strip() for k in ["name","contact","phone","email","contract_no","contract_start","contract_end","contract_cost","notes"]))
    con.commit(); con.close(); audit("إضافة مورد",request.form.get("name"))
    return redirect(url_for("suppliers"))

@app.route("/device/<code>/parts",methods=["GET","POST"])
@role_required("مديرة النظام","مشرفة","فني صيانة")
def parts(code):
    con=db(); d=con.execute("SELECT * FROM devices WHERE code=?",(code,)).fetchone()
    if not d: con.close(); return "الجهاز غير موجود",404
    if request.method=="POST":
        con.execute("""INSERT INTO spare_parts(device_id,name,quantity,unit_cost,used_date,technician,notes)
                       VALUES(?,?,?,?,?,?,?)""",(d["id"],request.form.get("name"),request.form.get("quantity") or 1,
                       request.form.get("unit_cost") or 0,request.form.get("used_date"),request.form.get("technician"),request.form.get("notes")))
        con.commit(); con.close(); audit("إضافة قطعة غيار",code)
        return redirect(url_for("parts",code=code))
    rows=con.execute("SELECT * FROM spare_parts WHERE device_id=? ORDER BY id DESC",(d["id"],)).fetchall()
    con.close(); return render_template("parts.html",d=d,parts=rows)

@app.route("/kpi")
@role_required("مديرة النظام","مشرفة")
def kpi():
    con=db()
    total=con.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
    working=con.execute("SELECT COUNT(*) FROM devices WHERE status='يعمل'").fetchone()[0]
    req=con.execute("SELECT COUNT(*) FROM service_requests").fetchone()[0]
    closed=con.execute("SELECT COUNT(*) FROM service_requests WHERE status='مغلق'").fetchone()[0]
    repair=con.execute("SELECT COALESCE(SUM(repair_cost),0) FROM service_requests").fetchone()[0]
    parts_cost=con.execute("SELECT COALESCE(SUM(quantity*unit_cost),0) FROM spare_parts").fetchone()[0]
    maint_cost=con.execute("SELECT COALESCE(SUM(cost),0) FROM maintenance").fetchone()[0]
    con.close()
    availability=round((working/total)*100,1) if total else 0
    closure=round((closed/req)*100,1) if req else 0
    return render_template("kpi.html",total=total,working=working,req=req,closed=closed,
                           repair=repair,parts_cost=parts_cost,maint_cost=maint_cost,
                           availability=availability,closure=closure)

@app.route("/alerts")
@role_required("مديرة النظام","مشرفة","فني صيانة","موظف")
def alerts():
    con=db()
    items=[]
    # Open faults
    rows=con.execute("""SELECT f.id,f.description,f.report_date,f.status,d.code,d.name
                        FROM faults f JOIN devices d ON d.id=f.device_id
                        WHERE f.status!='مغلق' ORDER BY f.id DESC""").fetchall()
    for r in rows:
        items.append({"type":"عطل","level":"high","title":f"عطل مفتوح: {r['name']}",
                      "text":r["description"] or "يوجد عطل يحتاج متابعة","date":r["report_date"],
                      "url":url_for("device",code=r["code"])})
    # Maintenance due
    rows=con.execute("""SELECT m.id,m.next_date,m.maintenance_type,d.code,d.name
                        FROM maintenance m JOIN devices d ON d.id=m.device_id
                        WHERE m.next_date IS NOT NULL AND date(m.next_date)<=date('now','+30 day')
                        ORDER BY date(m.next_date)""").fetchall()
    for r in rows:
        level="high" if r["next_date"] and r["next_date"] < __import__("datetime").date.today().isoformat() else "medium"
        items.append({"type":"صيانة","level":level,"title":f"صيانة: {r['name']}",
                      "text":f"{r['maintenance_type'] or 'صيانة دورية'} — الموعد {r['next_date']}",
                      "date":r["next_date"],"url":url_for("device",code=r["code"])})
    # Warranty
    rows=con.execute("""SELECT code,name,warranty_end FROM devices
                        WHERE warranty_end IS NOT NULL AND date(warranty_end)<=date('now','+30 day')
                        ORDER BY date(warranty_end)""").fetchall()
    for r in rows:
        items.append({"type":"ضمان","level":"medium","title":f"انتهاء ضمان: {r['name']}",
                      "text":f"نهاية الضمان {r['warranty_end']}","date":r["warranty_end"],
                      "url":url_for("device",code=r["code"])})
    con.close()
    order={"high":0,"medium":1,"low":2}
    items.sort(key=lambda x:(order.get(x["level"],9),str(x["date"] or "")))
    return render_template("alerts.html",items=items)

@app.route("/reports")
@role_required("مديرة النظام","مشرفة")
def reports():
    con=db()
    status=request.args.get("status","").strip()
    category=request.args.get("category","").strip()
    location=request.args.get("location","").strip()
    date_from=request.args.get("date_from","").strip()
    date_to=request.args.get("date_to","").strip()
    q="""SELECT * FROM devices WHERE 1=1"""
    args=[]
    if status: q+=" AND status=?"; args.append(status)
    if category: q+=" AND category=?"; args.append(category)
    if location: q+=" AND location=?"; args.append(location)
    if date_from: q+=" AND (purchase_date IS NULL OR purchase_date>=?)"; args.append(date_from)
    if date_to: q+=" AND (purchase_date IS NULL OR purchase_date<=?)"; args.append(date_to)
    q+=" ORDER BY id DESC"
    devices=con.execute(q,args).fetchall()
    categories=[r[0] for r in con.execute("SELECT DISTINCT category FROM devices WHERE category IS NOT NULL AND category!='' ORDER BY category").fetchall()]
    locations=[r[0] for r in con.execute("SELECT DISTINCT location FROM devices WHERE location IS NOT NULL AND location!='' ORDER BY location").fetchall()]
    faults=con.execute("""SELECT f.*,d.name device_name,d.code FROM faults f JOIN devices d ON d.id=f.device_id ORDER BY f.id DESC""").fetchall()
    maintenance=con.execute("""SELECT m.*,d.name device_name,d.code FROM maintenance m JOIN devices d ON d.id=m.device_id ORDER BY COALESCE(m.next_date,'9999-12-31')""").fetchall()
    con.close()
    return render_template("reports.html",devices=devices,faults=faults,maintenance=maintenance,
                           categories=categories,locations=locations,
                           filters={"status":status,"category":category,"location":location,"date_from":date_from,"date_to":date_to})

@app.route("/reports/export/csv")
@role_required("مديرة النظام","مشرفة")
def export_csv():
    import csv, io
    con=db()
    rows=con.execute("""SELECT code,name,category,manufacturer,model,serial_number,asset_number,
        purchase_date,purchase_price,service_years,warranty_start,warranty_end,location,status FROM devices ORDER BY id DESC""").fetchall()
    con.close()
    out=io.StringIO()
    w=csv.writer(out)
    w.writerow(["رمز الجهاز","اسم الجهاز","التصنيف","الشركة","الموديل","الرقم التسلسلي","رقم الأصل",
                "تاريخ الشراء","سعر الشراء","سنوات الخدمة","بداية الضمان","نهاية الضمان","الموقع","الحالة"])
    for r in rows: w.writerow(list(r))
    from flask import Response
    return Response("\ufeff"+out.getvalue(),mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition":"attachment; filename=nutrition-equipment.csv"})

@app.route("/reports/export/xlsx")
@role_required("مديرة النظام","مشرفة")
def export_xlsx():
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill
    from flask import send_file
    import io
    con=db()
    devices=con.execute("SELECT code,name,category,manufacturer,model,serial_number,asset_number,purchase_date,purchase_price,service_years,warranty_start,warranty_end,location,status FROM devices ORDER BY id DESC").fetchall()
    faults=con.execute("""SELECT d.code,d.name,f.fault_type,f.report_date,f.status,f.description,f.technician,f.repair_date,f.repair_cost
                         FROM faults f JOIN devices d ON d.id=f.device_id ORDER BY f.id DESC""").fetchall()
    maint=con.execute("""SELECT d.code,d.name,m.maintenance_type,m.maintenance_date,m.next_date,m.technician,m.cost,m.notes
                        FROM maintenance m JOIN devices d ON d.id=m.device_id ORDER BY m.id DESC""").fetchall()
    con.close()
    wb=Workbook()
    ws=wb.active; ws.title="الأجهزة"
    headers=["رمز الجهاز","اسم الجهاز","التصنيف","الشركة","الموديل","الرقم التسلسلي","رقم الأصل","تاريخ الشراء","سعر الشراء","سنوات الخدمة","بداية الضمان","نهاية الضمان","الموقع","الحالة"]
    ws.append(headers)
    for r in devices: ws.append(list(r))
    wf=wb.create_sheet("الأعطال")
    wf.append(["رمز الجهاز","اسم الجهاز","نوع العطل","تاريخ البلاغ","الحالة","الوصف","الفني","تاريخ الإصلاح","تكلفة الإصلاح"])
    for r in faults: wf.append(list(r))
    wm=wb.create_sheet("الصيانة")
    wm.append(["رمز الجهاز","اسم الجهاز","نوع الصيانة","تاريخ الصيانة","الصيانة القادمة","الفني","التكلفة","الملاحظات"])
    for r in maint: wm.append(list(r))
    for sheet in wb.worksheets:
        sheet.freeze_panes="A2"
        for cell in sheet[1]:
            cell.font=Font(bold=True,color="FFFFFF")
            cell.fill=PatternFill("solid",fgColor="176B63")
            cell.alignment=Alignment(horizontal="center")
        for col in sheet.columns:
            maxlen=min(max(len(str(c.value or "")) for c in col)+2,35)
            sheet.column_dimensions[col[0].column_letter].width=maxlen
    buf=io.BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf,as_attachment=True,download_name="nutrition-equipment-report.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.before_request
def security_check():
    if request.method=="POST" and request.endpoint not in ("static",):
        result=csrf_protect()
        if result: return result

@app.route("/health")
def health():
    return jsonify({"status":"ok","service":"Nutrition Equipment Management","cloud_ready":bool(os.getenv("DATABASE_URL"))})

@app.route("/dashboard")
def dashboard():
    if not login_required(): return redirect(url_for("login"))
    con=db()
    total=con.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
    working=con.execute("SELECT COUNT(*) FROM devices WHERE status='يعمل'").fetchone()[0]
    needs=con.execute("SELECT COUNT(*) FROM devices WHERE status='يحتاج صيانة'").fetchone()[0]
    out=con.execute("SELECT COUNT(*) FROM devices WHERE status='خارج الخدمة'").fetchone()[0]
    open_faults=con.execute("SELECT COUNT(*) FROM faults WHERE status!='مغلق'").fetchone()[0]
    warranty=con.execute("""SELECT COUNT(*) FROM devices
        WHERE warranty_end IS NOT NULL AND warranty_end!=''
        AND date(warranty_end) BETWEEN date('now') AND date('now','+30 day')""").fetchone()[0]
    maintenance=con.execute("""SELECT COUNT(*) FROM maintenance
        WHERE next_date IS NOT NULL AND date(next_date) BETWEEN date('now') AND date('now','+30 day')""").fetchone()[0]
    cost=con.execute("SELECT COALESCE(SUM(cost),0)+COALESCE((SELECT SUM(repair_cost) FROM faults),0) FROM maintenance").fetchone()[0]
    cats=con.execute("SELECT COALESCE(category,'غير مصنف') category, COUNT(*) count FROM devices GROUP BY category ORDER BY count DESC").fetchall()
    recent_faults=con.execute("""SELECT f.*,d.name,d.code FROM faults f JOIN devices d ON d.id=f.device_id
        WHERE f.status!='مغلق' ORDER BY f.id DESC LIMIT 6""").fetchall()
    upcoming=con.execute("""SELECT m.*,d.name,d.code FROM maintenance m JOIN devices d ON d.id=m.device_id
        WHERE m.next_date IS NOT NULL AND date(m.next_date)>=date('now') ORDER BY date(m.next_date) LIMIT 6""").fetchall()
    con.close()
    return render_template("dashboard.html", total=total,working=working,needs=needs,out=out,
        open_faults=open_faults,warranty=warranty,maintenance=maintenance,cost=cost,
        cats=cats,recent_faults=recent_faults,upcoming=upcoming)

@app.route("/")
def index():
    if not login_required(): return redirect(url_for("login"))
    con=db()
    devices=con.execute("SELECT * FROM devices ORDER BY id DESC").fetchall()
    con.close()
    return render_template("index.html", devices=devices, stats=stats())

@app.route("/device/<code>")
def device(code):
    if not login_required(): return redirect(url_for("login"))
    con=db()
    d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    if not d: abort(404)
    maint=con.execute("SELECT * FROM maintenance WHERE device_id=? ORDER BY maintenance_date DESC", (d["id"],)).fetchall()
    faults=con.execute("SELECT * FROM faults WHERE device_id=? ORDER BY id DESC", (d["id"],)).fetchall()
    docs=con.execute("SELECT * FROM documents WHERE device_id=? ORDER BY id DESC", (d["id"],)).fetchall()
    con.close()
    return render_template("device.html", d=d, maint=maint, faults=faults, docs=docs)

@app.route("/add", methods=["GET","POST"])
def add():
    if not login_required(): return redirect(url_for("login"))
    if request.method=="POST":
        f=request.form
        code=f.get("code") or f"NUT-{uuid.uuid4().hex[:8].upper()}"
        con=db()
        con.execute("""INSERT INTO devices
        (code,name,category,manufacturer,model,serial_number,asset_number,purchase_date,
         purchase_price,service_years,warranty_start,warranty_end,location,status)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (code,f["name"],f.get("category"),f.get("manufacturer"),f.get("model"),
         f.get("serial_number"),f.get("asset_number"),f.get("purchase_date"),
         float(f.get("purchase_price") or 0),int(f.get("service_years") or 0),
         f.get("warranty_start"),f.get("warranty_end"),f.get("location"),
         f.get("status") or "يعمل"))
        device_id = con.execute("SELECT id FROM devices WHERE code=?", (code,)).fetchone()["id"]
        audit(con, "إضافة جهاز", device_id)
        con.commit(); con.close()
        make_qr(code)
        return redirect(url_for("device", code=code))
    return render_template("add.html")

@app.post("/device/<code>/maintenance")
def add_maintenance(code):
    if not login_required(): return redirect(url_for("login"))
    con=db()
    d=con.execute("SELECT id FROM devices WHERE code=?", (code,)).fetchone()
    if not d: abort(404)
    f=request.form
    con.execute("""INSERT INTO maintenance
    (device_id,maintenance_date,next_date,maintenance_type,technician,company,cost,notes)
    VALUES (?,?,?,?,?,?,?,?)""",
    (d["id"],f.get("maintenance_date"),f.get("next_date"),f.get("maintenance_type"),
     f.get("technician"),f.get("company"),float(f.get("cost") or 0),f.get("notes")))
    audit(con, "إضافة سجل صيانة", d["id"])
    con.commit(); con.close()
    return redirect(url_for("device", code=code))

@app.post("/device/<code>/fault")
def add_fault(code):
    if not login_required(): return redirect(url_for("login"))
    con=db()
    d=con.execute("SELECT id FROM devices WHERE code=?", (code,)).fetchone()
    if not d: abort(404)
    f=request.form
    con.execute("""INSERT INTO faults
    (device_id,report_date,fault_type,description,reporter,status)
    VALUES (?,?,?,?,?,?)""",
    (d["id"],f.get("report_date") or date.today().isoformat(),f.get("fault_type"),
     f.get("description"),f.get("reporter"),"مفتوح"))
    con.execute("UPDATE devices SET status='يحتاج صيانة' WHERE id=?", (d["id"],))
    audit(con, "تسجيل بلاغ عطل", d["id"])
    con.commit(); con.close()
    return redirect(url_for("device", code=code))

@app.post("/fault/<int:fault_id>/close")
def close_fault(fault_id):
    if not login_required(): return redirect(url_for("login"))
    con=db()
    f=con.execute("SELECT device_id FROM faults WHERE id=?", (fault_id,)).fetchone()
    if not f: abort(404)
    data=request.form
    con.execute("""UPDATE faults SET status='مغلق', technician=?, repair_date=?,
                   repair_cost=?, notes=? WHERE id=?""",
                (data.get("technician"),data.get("repair_date") or date.today().isoformat(),
                 float(data.get("repair_cost") or 0),data.get("notes"),fault_id))
    remaining=con.execute("""SELECT COUNT(*) FROM faults
                             WHERE device_id=? AND status!='مغلق'""",(f["device_id"],)).fetchone()[0]
    if remaining==0:
        con.execute("UPDATE devices SET status='يعمل' WHERE id=?",(f["device_id"],))
    audit(con, "إغلاق بلاغ عطل", f["device_id"])
    con.commit(); con.close()
    return redirect(request.referrer or url_for("index"))


@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        con=db()
        u=con.execute("SELECT * FROM users WHERE username=? AND password=?",
                      (request.form.get("username"), request.form.get("password"))).fetchone()
        con.close()
        if u:
            session["user"]=u["username"]; session["role"]=u["role"]
            return redirect(url_for("index"))
        flash("بيانات الدخول غير صحيحة")
    return render_template("login.html")

@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.post("/device/<code>/document")
def upload_document(code):
    if not login_required(): return redirect(url_for("login"))
    con=db()
    d=con.execute("SELECT id FROM devices WHERE code=?", (code,)).fetchone()
    if not d: abort(404)
    file=request.files.get("file")
    title=request.form.get("title") or "وثيقة"
    if not file or not file.filename or not allowed_file(file.filename):
        flash("الملف غير مدعوم. استخدمي PDF أو Word أو صورة.")
        return redirect(url_for("device", code=code))
    ext=file.filename.rsplit(".",1)[1].lower()
    stored=f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], stored))
    con.execute("INSERT INTO documents(device_id,title,file_name) VALUES (?,?,?)",(d["id"],title,stored))
    audit(con, "رفع وثيقة", d["id"])
    con.commit(); con.close()
    return redirect(url_for("device", code=code))

@app.get("/api/device/<code>")
def api_device(code):
    con=db(); d=con.execute("SELECT * FROM devices WHERE code=?", (code,)).fetchone()
    con.close()
    if not d: return jsonify({"error":"غير موجود"}),404
    return jsonify(dict(d))

with app.app_context():
    init_db()
    if not os.path.exists(os.path.join(QR_DIR,"NUT-OVN-001.png")):
        make_qr("NUT-OVN-001")

if __name__ == "__main__":
    app.run(debug=True)
